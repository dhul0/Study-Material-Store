<?php  

    $conn=mysqli_connect('localhost','root','','sms') or die("Connection error : "+mysqli_connect_error());

  

?>