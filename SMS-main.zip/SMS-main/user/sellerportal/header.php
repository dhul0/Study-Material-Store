

<header>
        <div class="nav">
            
            <div class="heading"><a href="./">Seller Portal</a></div>
            <div class="nav_list">
                <ul>
                    <li><a href="./">Manage Product</a></li>
                    <li><a href="#">Order</a></li>
                    <li><a href="#">Settings</a></li>
                </ul>
            </div>
            <div class="exit">
               <a href="../" class="btn"> <i class="fa fa-sign-out" aria-hidden="true"></i> Exit</a>
            </div>
        </div>

</header>    