git remote add origin https://github.com/jenil59/SMS.git
git branch -M main
git push -u origin main