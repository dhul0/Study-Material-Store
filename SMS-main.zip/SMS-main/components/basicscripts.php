<script src="./components/assets/scripts/slider.js"></script>
<script src="./components/assets/scripts/navbar.js"></script>
<script src="./components/assets/scripts/main.js"></script>