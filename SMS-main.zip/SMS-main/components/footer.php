<footer>
                <div class="f-top">
                    <div class="sec about-sec">
                        <div class="f-logo-box">
                            <img src="./components/assets/images/img/logo-2.png" height="50px" width="250px" alt="">
                        </div>
                        <div class="about-text">
                            <h4>
                                about stufy material store
                            </h4>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure ea praesentium minima? Et soluta laborum fuga officiis consequatur a accusamus.</p>

                        </div>

                    </div>
                    <div class="sec link-sec link-1">

                        <ul>
                            <li class="head">Quick Links</li>
                            <li><a href="#">about us</a></li>
                            <li><a href="#">blogs</a></li>
                            <li><a href="#">privacy policy</a></li>
                            <li><a href="#">terms & conditions</a></li>
                            <li><a href="#">help</a></li>
                        </ul>

                    </div>
                    <div class="sec link-sec link-2">
                        <ul>
                            <li class="head">customer care</li>
                            <li><a href="#">contact us</a></li>
                            <li><a href="#">faqs</a></li>
                            <li><a href="#">testimonials</a></li>
                            <li><a href="#">partner with us</a></li>
                            <li><a href="#">link5</a></li>
                        </ul>
                    </div>
                    <div class="sec link-sec link-3">
                        <ul>
                            <li>
                                <div class="f-box">
                                    <span><i class="fas fa-map-marked-alt"></i>Address</span>
                                    <small>35, rols street surat</small>
                                </div>
                            </li>
                            <li>
                                <div class="f-box">
                                    <span><i class="fas fa-phone-alt"></i>Phone</span>
                                    <small>(+91) 99299009900 </small>
                                </div>
                            </li>
                            <li>
                                <div class="f-box">
                                    <span><i class="fas fa-envelope"></i>email</span>
                                    <small>site@studymaterialstore.com</small>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="f-bottom">
                    &copy;
                    <a href="#"> studymaterialstore.com </a></studymaterialstore.com>. 2021. All Rights Reserved

                </div>
            </footer>